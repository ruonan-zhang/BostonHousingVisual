Map Visualization Tool of Boston Property Dataset

Files included:
1. BostonHousingMap.ipynb
2. ast2018full.csv (51.5 MB)
3. ZIP_Codes.geojson (673 KB)

To run the notebook, store ast2018full.csv and ZIP_Codes.geojson into the working directory

Model required:
folium
branca
simplejson
ipywidgets

